// import React from 'react';

// class HelloComponent extends React.Component {
//     render() {
//         // return null;
//         // return "Hello";
//         // return 10;
//         // return true;
//         // return Symbol("Hello");
//         // return { id: 1, message: "Hello" };
//         return (
//             <React.Fragment>
//                 <h1 className="card">Hello World!</h1>
//                 <h1 className="card">Hello World Again!</h1>
//             </React.Fragment>
//         );
//     }
// }

// export default HelloComponent;

// -------------------------------------------------
// import React, { Component } from 'react';

// class HelloComponent extends Component {
//     render() {
//         return (
//             <React.Fragment>
//                 <h1 className="card">Hello World!</h1>
//                 <h1 className="card">Hello World Again!</h1>
//             </React.Fragment>
//         );
//     }
// }

// export default HelloComponent;

// ---------------------------------------------- Functions

// import React from 'react';

// // function HelloComponent() {
// //     return (
// //         <React.Fragment>
// //             <h1 className="card">Hello World!</h1>
// //             <h1 className="card">Hello World Again!</h1>
// //         </React.Fragment>
// //     );
// // }

// const HelloComponent = function () {
//     return (
//         <React.Fragment>
//             <h1 className="card">Hello World!</h1>
//             <h1 className="card">Hello World Again!</h1>
//         </React.Fragment>
//     );
// }

// export default HelloComponent;

// ------------------------------------------------------- Arrow

import React from 'react';

// const HelloComponent = () => {
//     return (
//         <React.Fragment>
//             <h1 className="card">Hello World!</h1>
//             <h1 className="card">Hello World Again!</h1>
//         </React.Fragment>
//     );
// }

const HelloComponent = () => (
    <React.Fragment>
        <h1 className="card">Hello World!</h1>
        <h1 className="card">Hello World Again!</h1>
    </React.Fragment>
);

export default HelloComponent;