import React, { Component } from 'react';

class ComponentWithProps extends Component {
    constructor(props) {
        super(props);

        // this.state = { name: "Synechron" };
        // this.props = { name: "Synechron" };  // Not Allowed
        // this.props.id = 100;        // Not Allowed, porps are readonly

        // this.state = this.props;
        // this.state.id = 100;

        // Shallow Copy
        // this.state = Object.assign({}, this.props);
        // this.state = {...this.props};
        // this.state.id = 100;
        // this.state.address.city = "Mumbai";

        // Deep Copy
        this.state = JSON.parse(JSON.stringify(this.props));
        this.state.id = 100;
        this.state.address.city = "Mumbai";

        // Deep Copy With Functions (Methods) - immutability-helper

        console.log("Ctor, State: ", this.state);
        console.log("Ctor, Props: ", this.props);
    }

    render() {
        console.log("Render, State: ", this.state);
        console.log("Render, Props: ", this.props);
        return (
            <div>
                <h2 className="text-info">Id, {this.state.id}</h2>
                <h2 className="text-info">City, {this.state.address.city}</h2>
            </div>
        );
    }
}

export default ComponentWithProps;