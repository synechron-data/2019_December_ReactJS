// import React from 'react';
// import ReactDOM from 'react-dom';
// import './index.css';   // Application level CSS

// import HelloComponent from './components/1_hello/HelloComponent';

// var r = ReactDOM.render(<HelloComponent />, document.getElementById('root'));
// console.log(r);

// ---------------------- Multiple Components

// import React from 'react';
// import ReactDOM from 'react-dom';
// import './index.css';

// import ComponentOne from './components/2_multi-components/ComponentOne';
// import ComponentTwo from './components/2_multi-components/ComponentTwo';

// ReactDOM.render(<ComponentOne />, document.getElementById('root1'));
// ReactDOM.render(<ComponentTwo />, document.getElementById('root2'));

// ReactDOM.render(<React.Fragment>
//     <ComponentOne />
//     <ComponentTwo />
// </React.Fragment>, document.getElementById('root'));

// ReactDOM.render([<ComponentOne />, <ComponentTwo />], document.getElementById('root'));

// ---------------------------- Using Root Component

// import React from 'react';
// import ReactDOM from 'react-dom';
// import './index.css'; 

// import RootComponent from './components/root/RootComponent';

// ReactDOM.render(<RootComponent />, document.getElementById('root'));

// // ----------------------------- Using Bootstrap 3
// // npm install --save bootstrap@3 jquery

// import 'bootstrap/dist/css/bootstrap.css';
// import 'bootstrap/dist/css/bootstrap-theme.css';

// import React from 'react';
// import ReactDOM from 'react-dom';
// import './index.css'; 

// import RootComponent from './components/root/RootComponent';

// const jQuery = require('jquery');
// window.jQuery = jQuery;

// require('bootstrap');

// ReactDOM.render(<RootComponent />, document.getElementById('root'));

// ----------------------------- Using Bootstrap 4
// npm install --save bootstrap popper.js jquery
// npm install --save-dev node-sass

import 'bootstrap/scss/bootstrap.scss';

import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap';

import './index.css'; 
import RootComponent from './components/root/RootComponent';

ReactDOM.render(<RootComponent />, document.getElementById('root'));