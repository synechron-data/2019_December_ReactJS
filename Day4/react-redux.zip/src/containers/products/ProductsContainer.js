import React, { Component } from 'react';
import { connect } from 'react-redux';

import * as productActions from '../../actions/productActions';
import ProductListComponent from '../../components/products/ProductListComponent';
import LoaderAnimation from '../../components/common/LoaderAnimation';

class ProductsContainer extends Component {
    render() {
        return (
            <React.Fragment>
                {this.props.products.length > 0 ?
                    <React.Fragment>
                        <ProductListComponent products={this.props.products} />
                    </React.Fragment>
                    :
                    <div className="pt-5">
                        <LoaderAnimation />
                    </div>
                }
            </React.Fragment>
        );
    }

    componentDidMount() {
        this.props.loadProducts();
    }
}

function mapStateToProps(state, ownProps) {
    return {
        products: state.productReducer.products
    };
}

function mapDispatchToProps(dispatch) {
    return {
        loadProducts: () => { dispatch(productActions.loadProducts()); }
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(ProductsContainer);