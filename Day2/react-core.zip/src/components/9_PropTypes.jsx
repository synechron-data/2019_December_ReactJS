import React, { Component } from 'react';
import PropTypes from 'prop-types';

class PropTypesComponent extends Component {
    render() {
        var ename = this.props.name.toUpperCase();
        return (
            <div>
                <h2 className="text-info">Hello, {ename}</h2>
            </div>
        );
    }

    static get propTypes() {
        return {
            name: PropTypes.string.isRequired
        };
    }
}


class PropTypesRoot extends Component {
    render() {
        return (
            <div>
                <PropTypesComponent name={"manish"}/>
            </div>
        );
    }
}

export default PropTypesRoot;