import React, { Component } from 'react';

class ComponentOne extends Component {
    render() {
        console.log(this.state);
        console.log(this.props);
        return (
            <div>
                <h1 className="text-info">Using Class Syntax</h1>
            </div>
        );
    }
}

// Functional / Stateless / Presentational
// const ComponentTwo = (props) => {
//     console.log(props);
//     return (
//         <div>
//             <h1 className="text-info">Using Arrow Syntax</h1>
//         </div>
//     );
// }

// const ComponentThree = ({ id, name }) => {
//     console.log(id);
//     console.log(name);
//     return (
//         <div>
//             <h1 className="text-info">Using Arrow Syntax</h1>
//         </div>
//     );
// }

const ComponentFour = ({ id, name, ...address }) => {
    console.log(id);
    console.log(name);
    console.log(address);
    return (
        <div>
            <h1 className="text-info">Using Arrow Syntax</h1>
        </div>
    );
}

class ClassVsFunctional extends Component {
    render() {
        return (
            <div>
                {/* <ComponentOne/> */}
                {/* <ComponentTwo id={1} name={"Manish"} city={"Pune"} state={"MH"}/> */}
                {/* <ComponentThree id={1} name={"Manish"} city={"Pune"} state={"MH"} /> */}
                <ComponentFour id={1} name={"Manish"} city={"Pune"} state={"MH"} />
            </div>
        );
    }
}

export default ClassVsFunctional;