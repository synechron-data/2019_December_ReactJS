import React, { Component } from 'react';
import ComponentWithBehavior from '../1_ComponentWithBehavior';
import ClassVsFunctional from '../2_ClassVsFunctional';
import EventComponent from '../3_EventObject';
import CounterAssignment from '../4_CounterAssignment';
import DataFlowAssignment from '../5_DataFlowAssignment';
import ControlledVsUncontrolled from '../6_ControlledVsUncontrolled';
import CalculatorAssignment from '../7_CalculatorAssignment';
import ListRoot from '../8_ListComponent';
import PropTypesRoot from '../9_PropTypes';

class RootComponent extends Component {
    render() {
        return (
            <div className="container">
                {/* <ComponentWithBehavior /> */}
                {/* <ClassVsFunctional /> */}
                {/* <EventComponent /> */}
                {/* <CounterAssignment /> */}
                {/* <DataFlowAssignment /> */}
                {/* <ControlledVsUncontrolled /> */}
                {/* <CalculatorAssignment/>  */}
                <ListRoot />
                {/* <PropTypesRoot /> */}
            </div>
        );
    }
}

export default RootComponent;